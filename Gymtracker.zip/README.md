# Gym Tracker — Calistenia

Sistema de seguimiento de entrenamientos de calistenia.

---

## 🖥️ Uso en PC (Windows)

**Doble clic en `INICIAR.bat`**

Se abre automáticamente el navegador con el tracker.

---

## 📱 Uso en Android

### Opción 1: Widget en pantalla de inicio (RECOMENDADO)

**Un solo tap para entrenar** 💪

**Instalación automática:**
```bash
# En Termux, ejecutar:
bash /storage/emulated/0/Documents/Acabado/gym_tracker/setup_android.sh
```

Luego:
1. Añadir widget **Termux:Widget** a la pantalla de inicio
2. Seleccionar **"GymTracker"**
3. ✅ **Tap en el widget** → Servidor lanzado + Navegador abierto

**Requisitos previos:**
- Termux + Termux:Widget + Termux:API desde F-Droid
- Syncthing sincronizando archivos a `/storage/emulated/0/Documents/Acabado/gym_tracker/`

### Opción 2: Manual (método tradicional)

```bash
cd /storage/emulated/0/Documents/Acabado/gym_tracker
python iniciar.py
```

---

## 📦 Archivos incluidos

**Core:**
- `gymtracker.html` - Interfaz web del tracker
- `gymplan.json` - Plan de entrenamiento
- `gym_data.json` - Base de datos de entrenamientos

**Lanzadores:**
- `INICIAR.bat` - Windows
- `iniciar.py` - PC + Android (con API REST)
- `iniciar_android.sh` - Android (Termux:Widget)
- `setup_android.sh` - Instalador automático Android

**Documentación:**
- `README.md` - Esta guía

**Total:** ~60KB

---

## ✨ Características

- ✅ Seguimiento de series y repeticiones
- ✅ Temporizador de descanso
- ✅ Progreso visual con gráficos
- ✅ Historial de entrenamientos
- ✅ Plan personalizado de calistenia
- ✅ **Persistencia en archivo JSON** (no depende del navegador)
- ✅ Sincronizable entre dispositivos (Syncthing, Git, etc.)
- ✅ Funciona 100% offline
- ✅ Compatible PC y Android

---

## 📊 Notas técnicas

### Sistema de persistencia

**Nuevo:** Los datos se guardan en `gym_data.json` en el directorio del proyecto.

- ✅ **Prioridad:** API REST → `gym_data.json`
- ✅ **Fallback:** localStorage del navegador si la API no está disponible
- ✅ **Backup doble:** Guarda en ambos sitios automáticamente
- ✅ **Sincronización:** Copia la carpeta completa para mover tus datos entre dispositivos

### Ventajas

- Los datos persisten fuera del navegador
- Puedes hacer backup manual copiando `gym_data.json`
- Sincronizable con Syncthing, Dropbox, Git, etc.
- Compatible con exportación/importación desde la app

### Configuración

- Puerto por defecto: 8000 (encuentra automáticamente uno libre si está ocupado)
- No requiere conexión a Internet una vez descargado
- Para resetear: Borrar `gym_data.json` o usar el botón "reset" en la app

---

## 🔧 Troubleshooting

**Problema:** El navegador no se abre automáticamente en Android

**Solución:** Abre Chrome manualmente y ve a:
```
http://localhost:8000/gymtracker.html
```

**Problema:** Puerto 8000 ocupado

**Solución:** El script encuentra automáticamente un puerto libre (8001, 8002, etc.)

---

---

## 🎯 Flujo de trabajo recomendado

### En PC (Windows)
1. Doble clic `INICIAR.bat`
2. Entrenar y registrar series
3. Cerrar navegador (datos guardados en `gym_data.json`)

### En Android (con widget)
1. **Tap** en widget "GymTracker"
2. Entrenar en el navegador
3. Cerrar cuando termines
4. Servidor sigue en background (tap "GymTracker-Stop" para detenerlo)

---

**Última actualización:** 2026-04-12
